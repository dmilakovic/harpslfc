"""
Compares an lsf2 dispersion solution (from an LSFLibrary, i.e. an
lsf2.cli_run output FITS file) against an independent WAVE_MATRIX
solution, order by order and across the whole detector.

Three kinds of residual are distinguished throughout, since they answer
different questions:
  - "vs theoretical": lsf2's own fitted line_position, converted to
    wavelength by EACH solution, compared to the LFC line's own
    known/theoretical wavelength (line_wavelength) -- this is each
    solution's own absolute accuracy at the LFC line positions.
  - "lsf2 - wave_matrix": the two solutions' wavelength (or velocity)
    difference, evaluated on a dense pixel grid -- a direct, continuous
    comparison that doesn't depend on where the LFC lines happen to fall.
  - "cross-order": the same two comparisons, but for orders/slices whose
    wavelength coverage overlaps, so the *same* wavelength is checked
    against two (or more) independent line measurements.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .reconstruct import LSFLibrary
from .wavematrix import WaveMatrix

C_MS = 2.99792458e8


def common_orders(lib: LSFLibrary, wavemat: WaveMatrix) -> list[int]:
    return sorted(set(lib.orders()) & set(wavemat.orders()))


@dataclass
class OrderComparison:
    order: int
    pixel: np.ndarray
    wavelength_lsf2_nm: np.ndarray
    wavelength_wavemat_nm: np.ndarray
    residual_ms: np.ndarray             # (lsf2 - wave_matrix), m/s

    line_wavelength_nm: np.ndarray      # theoretical LFC wavelength, per line
    line_position_lsf2: np.ndarray      # lsf2's own fitted pixel position, per line
    line_residual_lsf2_ms: np.ndarray   # lsf2's own solution vs theoretical, at its own fitted position
    line_residual_wavemat_ms: np.ndarray  # wave_matrix vs theoretical, evaluated AT lsf2's fitted position

    rms_ms: float
    median_ms: float
    qc_flag: bool = None


def compare_order(lib: LSFLibrary, wavemat: WaveMatrix, order: int, n_samples: int = 2000) -> OrderComparison:
    x_min, x_max, _ = lib.pixel_range(order)
    wm_lo, wm_hi = wavemat.wavelength_range_nm(order)
    # dense comparison only over the pixel range BOTH solutions actually cover
    pixel_lo = max(x_min, wavemat.pixel_at_wavelength(order, wm_lo))
    pixel_hi = min(x_max, wavemat.pixel_at_wavelength(order, wm_hi))
    if pixel_lo > pixel_hi:
        pixel_lo, pixel_hi = pixel_hi, pixel_lo
    pixel = np.linspace(pixel_lo, pixel_hi, n_samples)

    wavelength_lsf2 = lib.pixel_to_wavelength(order, pixel)
    wavelength_wavemat = wavemat.wavelength_nm(order, pixel)
    residual_ms = C_MS * (wavelength_lsf2 - wavelength_wavemat) / wavelength_wavemat

    row = lib._lsf_by_order[order]
    disp_row = lib._dispersion_by_order[order]
    line_wavelength = np.asarray(disp_row['LINE_WAVELENGTH'])
    line_position = np.asarray(disp_row['LINE_POSITION'])

    wavelength_lsf2_at_lines = lib.pixel_to_wavelength(order, line_position)
    wavelength_wavemat_at_lines = wavemat.wavelength_nm(order, line_position)
    line_residual_lsf2 = C_MS * (wavelength_lsf2_at_lines - line_wavelength) / line_wavelength
    line_residual_wavemat = C_MS * (wavelength_wavemat_at_lines - line_wavelength) / line_wavelength

    return OrderComparison(
        order=order, pixel=pixel,
        wavelength_lsf2_nm=wavelength_lsf2, wavelength_wavemat_nm=wavelength_wavemat,
        residual_ms=residual_ms,
        line_wavelength_nm=line_wavelength, line_position_lsf2=line_position,
        line_residual_lsf2_ms=line_residual_lsf2, line_residual_wavemat_ms=line_residual_wavemat,
        rms_ms=float(np.sqrt(np.mean(residual_ms ** 2))), median_ms=float(np.median(residual_ms)),
        qc_flag=wavemat.qc_flag.get(order),
    )


def summary_table(lib: LSFLibrary, wavemat: WaveMatrix, orders: list[int] = None) -> list[dict]:
    """ One row per common order: quick numbers for a sortable overview
        table (req. 3, "accuracy across different slices and orders"). """
    orders = orders if orders is not None else common_orders(lib, wavemat)
    rows = []
    for order in orders:
        cmp = compare_order(lib, wavemat, order)
        lo, hi = wavemat.wavelength_range_nm(order)
        rows.append({
            'order': order,
            'physical_order': wavemat.physical_order(order),
            'slice': wavemat.slice_index(order),
            'wave_lo_nm': lo, 'wave_hi_nm': hi,
            'rms_ms': cmp.rms_ms, 'median_ms': cmp.median_ms,
            'lsf2_line_rms_ms': float(np.sqrt(np.nanmean(cmp.line_residual_lsf2_ms ** 2))),
            'wavemat_line_rms_ms': float(np.sqrt(np.nanmean(cmp.line_residual_wavemat_ms ** 2))),
            'n_lines': len(cmp.line_wavelength_nm),
            'qc_flag': cmp.qc_flag,
        })
    return rows


def two_d_difference(lib: LSFLibrary, wavemat: WaveMatrix, orders: list[int] = None,
                      n_pixel_samples: int = 500):
    """ (pixel_grid, orders, diff_ms[order_index, pixel_index]) -- lsf2
        minus wave_matrix, sampled on a COMMON pixel grid (0..n_pixels-1,
        the physical detector axis shared by every order/slice) so it can
        be shown as a single 2D image across the whole order list. NaN
        where either solution doesn't cover that pixel for that order. """
    orders = sorted(orders) if orders is not None else common_orders(lib, wavemat)
    n_pixels_detector = wavemat.n_pixels
    pixel_grid = np.linspace(0, n_pixels_detector - 1, n_pixel_samples)
    diff = np.full((len(orders), n_pixel_samples), np.nan)

    for i, order in enumerate(orders):
        x_min, x_max, _ = lib.pixel_range(order)
        wm_mask = wavemat.valid_mask(order)
        if not wm_mask.any():
            continue
        wm_pixels = np.arange(n_pixels_detector)[wm_mask]
        wm_lo, wm_hi = wm_pixels.min(), wm_pixels.max()
        lo = max(x_min, wm_lo)
        hi = min(x_max, wm_hi)
        in_range = (pixel_grid >= lo) & (pixel_grid <= hi)
        if not in_range.any():
            continue
        px = pixel_grid[in_range]
        wavelength_lsf2 = lib.pixel_to_wavelength(order, px)
        wavelength_wavemat = wavemat.wavelength_nm(order, px)
        diff[i, in_range] = C_MS * (wavelength_lsf2 - wavelength_wavemat) / wavelength_wavemat

    return pixel_grid, orders, diff


def overlapping_orders_at_wavelength(lib: LSFLibrary, wavemat: WaveMatrix, wavelength_nm: float,
                                      orders: list[int] = None) -> list[int]:
    """ Every common order whose (lsf2 AND wave_matrix) coverage includes
        wavelength_nm -- the group to overplot for req. 2/3 (image-slicer
        slice pairs and/or adjacent overlapping echelle orders). """
    candidates = orders if orders is not None else common_orders(lib, wavemat)
    covering = []
    for order in candidates:
        lib_lo, lib_hi = lib.wavelength_range(order)
        wm_lo, wm_hi = wavemat.wavelength_range_nm(order)
        lo, hi = max(lib_lo, wm_lo), min(lib_hi, wm_hi)
        if lo <= wavelength_nm <= hi:
            covering.append(order)
    return covering
