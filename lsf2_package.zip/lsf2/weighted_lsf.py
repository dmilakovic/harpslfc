"""
Weighted-average LSF over a wavelength RANGE (as opposed to
reconstruct.LSFLibrary.composite_lsf_at_wavelength, which combines
orders at a single point). A "segment" here is one (order, wavelength)
sample -- generate_segments() lays down N evenly-spaced samples per
order across whatever part of [wave_lo, wave_hi] that order covers, so
an order that only partially overlaps the range contributes only from
its overlapping portion, and a range spanning several orders naturally
gets segments from each of them.

Weights are supplied by the caller (e.g. per-segment S/N from the GUI's
table) and normalised to sum to 1 at compute time; they are NOT
re-derived from the data here.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime, timezone

import numpy as np
from astropy.io import fits

from .reconstruct import LSFLibrary

C_KMS = 2.99792458e5


def velocity_range_to_wavelength(center_nm: float, velocity_kms_fullwidth: float) -> tuple[float, float]:
    """ [center*(1-v/2c), center*(1+v/2c)] -- velocity_kms_fullwidth is
        the FULL width of the window (i.e. +/- half that in velocity). """
    half = velocity_kms_fullwidth / 2.0
    return center_nm * (1 - half / C_KMS), center_nm * (1 + half / C_KMS)


def generate_segments(lib: LSFLibrary, wave_lo: float, wave_hi: float,
                       n_segments_per_order: int = 5, orders: list[int] = None) -> list[dict]:
    """ One dict {'order': int, 'wavelength': float} per segment, evenly
        spaced across each covering order's overlap with [wave_lo, wave_hi]. """
    if wave_hi < wave_lo:
        wave_lo, wave_hi = wave_hi, wave_lo
    candidates = orders if orders is not None else lib.orders()
    segments = []
    for order in candidates:
        lo_o, hi_o = lib.wavelength_range(order)
        lo, hi = max(lo_o, wave_lo), min(hi_o, wave_hi)
        if lo >= hi:
            continue
        wavelengths = [0.5 * (lo + hi)] if n_segments_per_order <= 1 else np.linspace(lo, hi, n_segments_per_order)
        for w in wavelengths:
            segments.append({'order': int(order), 'wavelength': float(w)})
    return segments


@dataclass
class WeightedLSFResult:
    u: np.ndarray
    phi: np.ndarray
    center_wavelength_nm: float
    velocity_range_kms: float          # NaN if the direct lo/hi input method was used
    wave_lo_nm: float
    wave_hi_nm: float
    segments: list                     # [{'order','wavelength','weight','weight_norm'}, ...]
    per_segment_phi: list = field(default_factory=list)   # each already scaled by weight_norm
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S'))


def compute_weighted_lsf(lib: LSFLibrary, segments: list[dict], weights: list[float],
                          center_wavelength_nm: float = np.nan, velocity_range_kms: float = np.nan,
                          wave_lo_nm: float = np.nan, wave_hi_nm: float = np.nan,
                          u_grid: np.ndarray = None) -> WeightedLSFResult:
    if not segments:
        raise ValueError("compute_weighted_lsf: no segments given")
    if len(weights) != len(segments):
        raise ValueError("weights must have the same length as segments")
    w_total = float(np.sum(weights))
    if w_total <= 0:
        raise ValueError("weights must sum to a positive number")

    contributions = [lib.lsf_at_wavelength(seg['order'], seg['wavelength']) for seg in segments]

    if u_grid is None:
        half_range = max(u.max() for u, _ in contributions)
        du = min(u[1] - u[0] for u, _ in contributions)
        n = int(round(2 * half_range / du)) + 1
        u_grid = np.linspace(-half_range, half_range, n)

    phi = np.zeros_like(u_grid)
    per_segment_phi = []
    out_segments = []
    for seg, w, (u, seg_phi) in zip(segments, weights, contributions):
        w_norm = w / w_total
        contribution = np.interp(u_grid, u, seg_phi, left=0.0, right=0.0) * w_norm
        phi += contribution
        per_segment_phi.append(contribution)
        out_segments.append({**seg, 'weight': float(w), 'weight_norm': float(w_norm)})

    if np.isnan(wave_lo_nm):
        wave_lo_nm = min(s['wavelength'] for s in segments)
    if np.isnan(wave_hi_nm):
        wave_hi_nm = max(s['wavelength'] for s in segments)
    if np.isnan(center_wavelength_nm):
        center_wavelength_nm = 0.5 * (wave_lo_nm + wave_hi_nm)

    return WeightedLSFResult(
        u=u_grid, phi=phi, center_wavelength_nm=center_wavelength_nm,
        velocity_range_kms=velocity_range_kms, wave_lo_nm=wave_lo_nm, wave_hi_nm=wave_hi_nm,
        segments=out_segments, per_segment_phi=per_segment_phi,
    )


def _unique_hdu_name(hdul: fits.HDUList, base_name: str) -> str:
    existing = {h.name for h in hdul}
    if base_name not in existing:
        return base_name
    i = 2
    while f"{base_name}_{i}" in existing:
        i += 1
    return f"{base_name}_{i}"


def save_weighted_lsf_fits(result: WeightedLSFResult, path: str, hdu_name: str = "WEIGHTED_LSF",
                            overwrite_hdu: bool = False) -> tuple[str, str]:
    """ Saves `result` as two extensions -- <hdu_name> (a U_KMS/PHI
        binary table) and <hdu_name>_SEGMENTS (per-segment provenance:
        order, wavelength, weight, normalised weight) -- appended to
        `path` if it already exists, or written to a new file otherwise.
        Returns (path, hdu_name actually used). """
    if os.path.exists(path):
        with fits.open(path) as hdul:
            hdul = fits.HDUList([h.copy() for h in hdul])
    else:
        hdul = fits.HDUList([fits.PrimaryHDU()])

    name = hdu_name if overwrite_hdu else _unique_hdu_name(hdul, hdu_name)
    if overwrite_hdu and name in {h.name for h in hdul}:
        for seg_name in (name, f"{name}_SEGMENTS"):
            if seg_name in hdul:
                del hdul[seg_name]

    lsf_hdu = fits.BinTableHDU.from_columns([
        fits.Column(name='U_KMS', format='D', array=result.u),
        fits.Column(name='PHI', format='D', array=result.phi),
    ], name=name)
    lsf_hdu.header['CENTRWL'] = (result.center_wavelength_nm, 'Central wavelength [nm]')
    velrange = result.velocity_range_kms
    lsf_hdu.header['VELRANGE'] = ('N/A' if not np.isfinite(velrange) else velrange,
                                   'Velocity FWHM window [km/s] (N/A: direct range)')
    lsf_hdu.header['WAVE_LO'] = (result.wave_lo_nm, 'Lower wavelength bound [nm]')
    lsf_hdu.header['WAVE_HI'] = (result.wave_hi_nm, 'Upper wavelength bound [nm]')
    lsf_hdu.header['NSEG'] = (len(result.segments), 'Number of contributing segments')
    lsf_hdu.header['DATE'] = result.created_at
    lsf_hdu.header['COMMENT'] = 'Weighted-average LSF built by harps.lsf2.weighted_lsf. See <name>_SEGMENTS.'

    orders = [s['order'] for s in result.segments]
    wavelengths = [s['wavelength'] for s in result.segments]
    weights = [s['weight'] for s in result.segments]
    weights_norm = [s['weight_norm'] for s in result.segments]
    segments_hdu = fits.BinTableHDU.from_columns([
        fits.Column(name='ORDER', format='J', array=np.array(orders)),
        fits.Column(name='WAVELENGTH', format='D', array=np.array(wavelengths)),
        fits.Column(name='WEIGHT', format='D', array=np.array(weights)),
        fits.Column(name='WEIGHT_NORM', format='D', array=np.array(weights_norm)),
    ], name=f"{name}_SEGMENTS")

    hdul.append(lsf_hdu)
    hdul.append(segments_hdu)
    hdul.writeto(path, overwrite=True)
    return path, name


def load_weighted_lsf_fits(path: str, hdu_name: str = "WEIGHTED_LSF") -> WeightedLSFResult:
    with fits.open(path) as hdul:
        lsf_hdu = hdul[hdu_name]
        seg_hdu = hdul[f"{hdu_name}_SEGMENTS"]
        u = np.asarray(lsf_hdu.data['U_KMS'], dtype=float)
        phi = np.asarray(lsf_hdu.data['PHI'], dtype=float)
        header = lsf_hdu.header
        velrange = header.get('VELRANGE', np.nan)
        if isinstance(velrange, str):
            velrange = np.nan
        segments = [
            {'order': int(o), 'wavelength': float(w), 'weight': float(wt), 'weight_norm': float(wn)}
            for o, w, wt, wn in zip(seg_hdu.data['ORDER'], seg_hdu.data['WAVELENGTH'],
                                     seg_hdu.data['WEIGHT'], seg_hdu.data['WEIGHT_NORM'])
        ]
    return WeightedLSFResult(
        u=u, phi=phi, center_wavelength_nm=header.get('CENTRWL', np.nan),
        velocity_range_kms=velrange,
        wave_lo_nm=header.get('WAVE_LO', np.nan), wave_hi_nm=header.get('WAVE_HI', np.nan),
        segments=segments, created_at=header.get('DATE', ''),
    )
