#!/usr/bin/env python
"""
GUI comparing an lsf2 dispersion solution (an lsf2.cli_run output FITS
file) against an independent ESO WAVE_MATRIX solution.

Usage:
    python -m harps.lsf2.wavecal_gui [LSF2_FITS] [WAVE_MATRIX_FITS]

Requires PyQt5, same as harps.lsf2.gui.

Four tabs, one per requirement this tool was built for:
  1. "Per-order accuracy" -- lsf2 vs wave_matrix, and each vs the LFC's
     own theoretical line wavelengths, for one order at a time.
  2. "Overlapping spectra" -- for a chosen wavelength, every order/slice
     that covers it, with the observed LFC spectrum overplotted under
     each order's own calibration (needs the original S2D flux; optional).
  3. "Summary table" -- RMS/median residual per order, sortable, to spot
     which orders/slices are worst at a glance.
  4. "2D difference" -- lsf2 minus wave_matrix, order x pixel, as an
     image, for detector-wide systematics.
"""
from __future__ import annotations

import sys

import numpy as np

try:
    from PyQt5 import QtCore, QtWidgets
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "harps.lsf2.wavecal_gui needs PyQt5 ('pip install PyQt5'); it is "
        "not a dependency of the rest of harps.lsf2."
    ) from exc

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
import matplotlib

from .reconstruct import LSFLibrary
from .wavematrix import WaveMatrix
from .flux_source import FluxSource
from . import wavecal_compare as wc


class MplCanvas(FigureCanvas):
    def __init__(self, nrows=1, ncols=1, figsize=(8, 6), **subplot_kw):
        self.fig = Figure(figsize=figsize)
        self.axes = self.fig.subplots(nrows, ncols, **subplot_kw)
        super().__init__(self.fig)


# =============================================================================
# Tab 1: per-order accuracy
# =============================================================================
class PerOrderTab(QtWidgets.QWidget):
    def __init__(self, lib: LSFLibrary, wavemat: WaveMatrix, parent=None):
        super().__init__(parent)
        self.lib, self.wavemat = lib, wavemat
        self.orders = wc.common_orders(lib, wavemat)

        self.order_combo = QtWidgets.QComboBox()
        for order in self.orders:
            lo, hi = wavemat.wavelength_range_nm(order)
            qc = wavemat.qc_flag.get(order)
            qc_str = '' if qc is None else (' [QC ok]' if qc else ' [QC FAIL]')
            self.order_combo.addItem(f"{order}  ({lo:.2f}-{hi:.2f} nm){qc_str}", userData=order)

        self.unit_combo = QtWidgets.QComboBox()
        self.unit_combo.addItems(["m/s", "pixels", "nm"])

        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Order:"))
        top.addWidget(self.order_combo, 1)
        top.addWidget(QtWidgets.QLabel("Units:"))
        top.addWidget(self.unit_combo)

        self.canvas = MplCanvas(nrows=2, ncols=1, figsize=(9, 8), sharex=True,
                                 gridspec_kw={'height_ratios': [2, 1]})
        toolbar = NavigationToolbar(self.canvas, self)

        self.stats_label = QtWidgets.QLabel()
        self.stats_label.setStyleSheet("font-family: monospace;")

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(toolbar)
        layout.addWidget(self.canvas, 1)
        layout.addWidget(self.stats_label)

        self.order_combo.currentIndexChanged.connect(self.redraw)
        self.unit_combo.currentIndexChanged.connect(self.redraw)
        if self.orders:
            self.redraw()

    def redraw(self):
        if not self.orders:
            return
        order = self.order_combo.currentData()
        cmp = wc.compare_order(self.lib, self.wavemat, order)
        unit = self.unit_combo.currentText()

        ax_top, ax_bot = self.canvas.axes
        ax_top.clear()
        ax_bot.clear()

        if unit == 'm/s':
            continuous = cmp.residual_ms
            line_lsf2 = cmp.line_residual_lsf2_ms
            line_wm = cmp.line_residual_wavemat_ms
            ylabel = 'residual [m/s]'
        elif unit == 'nm':
            continuous = cmp.wavelength_lsf2_nm - cmp.wavelength_wavemat_nm
            line_lsf2 = (cmp.line_residual_lsf2_ms / wc.C_MS) * cmp.line_wavelength_nm
            line_wm = (cmp.line_residual_wavemat_ms / wc.C_MS) * cmp.line_wavelength_nm
            ylabel = 'residual [nm]'
        else:  # pixels
            v_pix_scale = (cmp.pixel[-1] - cmp.pixel[0]) / max(
                (cmp.wavelength_wavemat_nm[-1] - cmp.wavelength_wavemat_nm[0]), 1e-30)
            continuous = (cmp.residual_ms / wc.C_MS) * cmp.wavelength_wavemat_nm * v_pix_scale
            line_lsf2 = (cmp.line_residual_lsf2_ms / wc.C_MS) * cmp.line_wavelength_nm * v_pix_scale
            line_wm = (cmp.line_residual_wavemat_ms / wc.C_MS) * cmp.line_wavelength_nm * v_pix_scale
            ylabel = 'residual [pixels]'

        ax_top.plot(cmp.pixel, continuous, color='tab:purple', lw=1.2,
                    label='lsf2 - wave_matrix (continuous)')
        ax_top.axhline(0, color='gray', lw=0.5)
        finite = continuous[np.isfinite(continuous)]
        if finite.size:
            lo, hi = np.nanpercentile(finite, [1, 99])
            pad = 0.25 * max(hi - lo, 1e-9)
            ax_top.set_ylim(lo - pad, hi + pad)
        ax_top.legend(fontsize=8)
        ax_top.set_ylabel(ylabel)
        ax_top.set_title(f"Order {order}: lsf2 vs wave_matrix")

        ax_bot.plot(cmp.line_position_lsf2, line_lsf2, '.', ms=5, color='tab:blue',
                    label='lsf2 vs theoretical (at lsf2 line positions)')
        ax_bot.plot(cmp.line_position_lsf2, line_wm, '.', ms=5, color='tab:red',
                    label='wave_matrix vs theoretical (same positions)')
        ax_bot.axhline(0, color='gray', lw=0.5)
        ax_bot.legend(fontsize=7)
        ax_bot.set_xlabel('pixel')
        ax_bot.set_ylabel(ylabel)
        ax_bot.set_title('Per-line residuals vs. theoretical LFC wavelength')

        self.canvas.fig.tight_layout()
        self.canvas.draw_idle()

        qc = wavemat_qc = self.wavemat.qc_flag.get(order)
        self.stats_label.setText(
            f"RMS(lsf2-wave_matrix) = {cmp.rms_ms:.3f} m/s   |   "
            f"median = {cmp.median_ms:+.3f} m/s   |   "
            f"lsf2 line RMS = {np.sqrt(np.nanmean(cmp.line_residual_lsf2_ms**2)):.3f} m/s   |   "
            f"wave_matrix line RMS = {np.sqrt(np.nanmean(cmp.line_residual_wavemat_ms**2)):.3f} m/s   |   "
            f"n_lines = {len(cmp.line_wavelength_nm)}   |   "
            f"ESO QC = {'--' if wavemat_qc is None else ('OK' if wavemat_qc else 'FAIL')}"
        )


# =============================================================================
# Tab 2: overlapping orders / slices -- overplot the LFC spectrum
# =============================================================================
class OverlapTab(QtWidgets.QWidget):
    def __init__(self, lib: LSFLibrary, wavemat: WaveMatrix, flux: FluxSource, parent=None):
        super().__init__(parent)
        self.lib, self.wavemat, self.flux = lib, wavemat, flux
        self.orders = wc.common_orders(lib, wavemat)
        lo_all = min(wavemat.wavelength_range_nm(o)[0] for o in self.orders)
        hi_all = max(wavemat.wavelength_range_nm(o)[1] for o in self.orders)

        self.wavelength_spin = QtWidgets.QDoubleSpinBox()
        self.wavelength_spin.setDecimals(4)
        self.wavelength_spin.setRange(lo_all, hi_all)
        self.wavelength_spin.setValue(0.5 * (lo_all + hi_all))

        self.window_spin = QtWidgets.QDoubleSpinBox()
        self.window_spin.setDecimals(3)
        self.window_spin.setRange(0.001, 5.0)
        self.window_spin.setValue(0.05)
        self.window_spin.setSuffix(" nm")

        self.calibration_combo = QtWidgets.QComboBox()
        self.calibration_combo.addItems(["lsf2 calibration", "wave_matrix calibration"])

        self.detect_button = QtWidgets.QPushButton("Find overlapping orders/slices")

        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Wavelength [nm]:"))
        top.addWidget(self.wavelength_spin)
        top.addWidget(QtWidgets.QLabel("+/- window:"))
        top.addWidget(self.window_spin)
        top.addWidget(QtWidgets.QLabel("Plot x-axis from:"))
        top.addWidget(self.calibration_combo)
        top.addWidget(self.detect_button)
        top.addStretch(1)

        self.info_label = QtWidgets.QLabel()
        self.canvas = MplCanvas(nrows=1, ncols=1, figsize=(9, 6))
        toolbar = NavigationToolbar(self.canvas, self)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self.info_label)
        layout.addWidget(toolbar)
        layout.addWidget(self.canvas, 1)

        self.detect_button.clicked.connect(self.redraw)
        self.calibration_combo.currentIndexChanged.connect(self.redraw)
        self.redraw()

    def redraw(self):
        wavelength = self.wavelength_spin.value()
        window = self.window_spin.value()
        covering = wc.overlapping_orders_at_wavelength(self.lib, self.wavemat, wavelength, self.orders)

        ax = self.canvas.axes
        ax.clear()

        if not covering:
            self.info_label.setText(f"No order/slice covers {wavelength:.4f} nm.")
            self.canvas.draw_idle()
            return

        self.info_label.setText(
            f"{len(covering)} order(s)/slice(s) cover {wavelength:.4f} nm: {covering}"
            + ("" if self.flux is not None else
               "   (load an S2D exposure via File > Load spectrum to see the actual LFC flux)")
        )

        if self.flux is None:
            ax.set_title("No spectrum loaded -- File > Load spectrum (S2D exposure)")
            self.canvas.fig.tight_layout()
            self.canvas.draw_idle()
            return

        use_lsf2 = self.calibration_combo.currentIndex() == 0
        cmap = matplotlib.colormaps.get_cmap('tab10')
        for i, order in enumerate(covering):
            x_min, x_max, n_pixels = self.lib.pixel_range(order)
            pixel = np.arange(min(n_pixels, self.flux.n_pixels))
            if use_lsf2:
                wavelength_axis = self.lib.pixel_to_wavelength(order, pixel)
            else:
                wavelength_axis = self.wavemat.wavelength_nm(order, pixel)
            mask = np.abs(wavelength_axis - wavelength) <= window
            if not mask.any():
                continue
            flux_row = self.flux.order_flux(order)[:len(pixel)]
            ax.plot(wavelength_axis[mask], flux_row[mask], '.-', ms=3, lw=0.8,
                    color=cmap(i % 10), label=f'order {order}')

        ax.axvline(wavelength, color='k', ls=':', lw=1)
        ax.legend(fontsize=8)
        ax.set_xlabel('wavelength [nm]' + f'  ({self.calibration_combo.currentText()})')
        ax.set_ylabel('flux [counts]')
        ax.set_title(f'LFC spectrum, overlapping orders near {wavelength:.4f} nm')

        self.canvas.fig.tight_layout()
        self.canvas.draw_idle()


# =============================================================================
# Tab 3: summary table across all orders
# =============================================================================
class SummaryTab(QtWidgets.QWidget):
    COLUMNS = [
        ('order', 'Order'), ('physical_order', 'Phys. order'), ('slice', 'Slice'),
        ('wave_lo_nm', 'Wave lo [nm]'), ('wave_hi_nm', 'Wave hi [nm]'),
        ('rms_ms', 'RMS(lsf2-WM) [m/s]'), ('median_ms', 'Median(lsf2-WM) [m/s]'),
        ('lsf2_line_rms_ms', 'lsf2 line RMS [m/s]'), ('wavemat_line_rms_ms', 'WM line RMS [m/s]'),
        ('n_lines', 'N lines'), ('qc_flag', 'ESO QC'),
    ]

    def __init__(self, lib: LSFLibrary, wavemat: WaveMatrix, parent=None):
        super().__init__(parent)
        self.lib, self.wavemat = lib, wavemat

        self.refresh_button = QtWidgets.QPushButton("Recompute")
        self.table = QtWidgets.QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels([label for _, label in self.COLUMNS])
        self.table.setSortingEnabled(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self.refresh_button)
        layout.addWidget(self.table)

        self.refresh_button.clicked.connect(self.refresh)
        self.refresh()

    def refresh(self):
        rows = wc.summary_table(self.lib, self.wavemat)
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, (key, _) in enumerate(self.COLUMNS):
                value = row[key]
                if key == 'qc_flag':
                    text = '--' if value is None else ('OK' if value else 'FAIL')
                elif isinstance(value, float):
                    text = f"{value:.4f}"
                else:
                    text = str(value)
                item = QtWidgets.QTableWidgetItem()
                item.setData(QtCore.Qt.DisplayRole, text if isinstance(value, (str, type(None))) or key == 'qc_flag'
                             else (value if not isinstance(value, float) else round(value, 6)))
                if key == 'qc_flag' and value is False:
                    item.setBackground(QtCore.Qt.red)
                self.table.setItem(r, c, item)
        self.table.setSortingEnabled(True)
        self.table.resizeColumnsToContents()


# =============================================================================
# Tab 4: 2D difference across the whole detector
# =============================================================================
class TwoDDiffTab(QtWidgets.QWidget):
    def __init__(self, lib: LSFLibrary, wavemat: WaveMatrix, parent=None):
        super().__init__(parent)
        self.lib, self.wavemat = lib, wavemat

        self.recompute_button = QtWidgets.QPushButton("Recompute")
        self.vmax_spin = QtWidgets.QDoubleSpinBox()
        self.vmax_spin.setRange(0, 1e6)
        self.vmax_spin.setValue(50.0)
        self.vmax_spin.setSuffix(" m/s (colour limit, 0 = auto)")

        top = QtWidgets.QHBoxLayout()
        top.addWidget(self.recompute_button)
        top.addWidget(self.vmax_spin)
        top.addStretch(1)

        self.canvas = MplCanvas(nrows=1, ncols=1, figsize=(10, 7))
        toolbar = NavigationToolbar(self.canvas, self)

        layout = QtWidgets.QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(toolbar)
        layout.addWidget(self.canvas, 1)

        self.recompute_button.clicked.connect(self.redraw)
        self.vmax_spin.valueChanged.connect(self.redraw)
        self.redraw()

    def redraw(self):
        pixel_grid, orders, diff = wc.two_d_difference(self.lib, self.wavemat)

        self.canvas.fig.clear()
        ax = self.canvas.fig.subplots(1, 1)

        vmax = self.vmax_spin.value()
        if vmax <= 0:
            finite = diff[np.isfinite(diff)]
            vmax = float(np.nanpercentile(np.abs(finite), 95)) if finite.size else 1.0

        im = ax.imshow(diff, aspect='auto', origin='lower', cmap='RdBu_r',
                        extent=[pixel_grid.min(), pixel_grid.max(), -0.5, len(orders) - 0.5],
                        vmin=-vmax, vmax=vmax)
        self.canvas.fig.colorbar(im, ax=ax, label='lsf2 - wave_matrix [m/s]')

        step = max(1, len(orders) // 40)
        ax.set_yticks(range(0, len(orders), step))
        ax.set_yticklabels([str(orders[i]) for i in range(0, len(orders), step)], fontsize=7)
        ax.set_xlabel('pixel')
        ax.set_ylabel('order')
        ax.set_title('lsf2 - wave_matrix, across the whole detector')

        self.canvas.fig.tight_layout()
        self.canvas.draw_idle()


# =============================================================================
# Main window
# =============================================================================
class WavecalDiagnosticsWindow(QtWidgets.QMainWindow):
    def __init__(self, lsf2_path: str = None, wavematrix_path: str = None):
        super().__init__()
        self.setWindowTitle("harps.lsf2 -- wavelength calibration diagnostics")
        self.resize(1250, 850)

        self.lib: LSFLibrary = None
        self.wavemat: WaveMatrix = None
        self.flux: FluxSource = None

        self.tabs = QtWidgets.QTabWidget()
        self.setCentralWidget(self.tabs)
        self.status = self.statusBar()

        file_menu = self.menuBar().addMenu("&File")
        open_lsf2 = QtWidgets.QAction("Open lsf2 FITS...", self)
        open_lsf2.triggered.connect(self.open_lsf2_dialog)
        open_wavemat = QtWidgets.QAction("Open WAVE_MATRIX FITS...", self)
        open_wavemat.triggered.connect(self.open_wavematrix_dialog)
        open_flux = QtWidgets.QAction("Load spectrum (S2D exposure)...", self)
        open_flux.triggered.connect(self.open_flux_dialog)
        file_menu.addAction(open_lsf2)
        file_menu.addAction(open_wavemat)
        file_menu.addAction(open_flux)

        if lsf2_path:
            self._load_lsf2(lsf2_path)
        if wavematrix_path:
            self._load_wavematrix(wavematrix_path)

    def open_lsf2_dialog(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open lsf2 output FITS", "", "FITS files (*.fits *.fit)")
        if path:
            self._load_lsf2(path)

    def open_wavematrix_dialog(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open WAVE_MATRIX FITS", "", "FITS files (*.fits *.fit)")
        if path:
            self._load_wavematrix(path)

    def open_flux_dialog(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open S2D exposure FITS", "", "FITS files (*.fits *.fit)")
        if path:
            try:
                self.flux = FluxSource.load(path)
            except Exception as exc:
                QtWidgets.QMessageBox.critical(self, "Failed to load spectrum", str(exc))
                return
            self._rebuild_tabs()

    def _load_lsf2(self, path):
        try:
            self.lib = LSFLibrary(path)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Failed to open lsf2 FITS", str(exc))
            return
        self._rebuild_tabs()

    def _load_wavematrix(self, path):
        try:
            self.wavemat = WaveMatrix.load(path)
        except Exception as exc:
            QtWidgets.QMessageBox.critical(self, "Failed to open WAVE_MATRIX FITS", str(exc))
            return
        self._rebuild_tabs()

    def _rebuild_tabs(self):
        self.tabs.clear()
        if self.lib is None or self.wavemat is None:
            self.status.showMessage("Load both an lsf2 FITS file and a WAVE_MATRIX FITS file to begin.")
            return

        n_common = len(wc.common_orders(self.lib, self.wavemat))
        if n_common == 0:
            QtWidgets.QMessageBox.warning(
                self, "No common orders",
                "The lsf2 file and the WAVE_MATRIX file share no order index in common -- "
                "check that both refer to the same instrument/order numbering.")

        self.tabs.addTab(PerOrderTab(self.lib, self.wavemat), "Per-order accuracy")
        self.tabs.addTab(OverlapTab(self.lib, self.wavemat, self.flux), "Overlapping spectra")
        self.tabs.addTab(SummaryTab(self.lib, self.wavemat), "Summary table")
        self.tabs.addTab(TwoDDiffTab(self.lib, self.wavemat), "2D difference")
        self.status.showMessage(f"{n_common} common order(s) between lsf2 and wave_matrix.")


def main(argv=None):
    argv = sys.argv if argv is None else argv
    app = QtWidgets.QApplication(argv)
    lsf2_path = argv[1] if len(argv) > 1 else None
    wavematrix_path = argv[2] if len(argv) > 2 else None
    window = WavecalDiagnosticsWindow(lsf2_path, wavematrix_path)
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
