#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 11:43:10 2023

@author: dmilakov
"""

__all__ = ['aux','classes','construct','gp','gp_aux','inout','plot',
           'read','write']